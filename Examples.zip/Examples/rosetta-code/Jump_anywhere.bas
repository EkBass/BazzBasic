' ============================================
' GOTO / GOSUB presentation for BazzBasic
' BazzBasic supports dynamic calls
' https://rosettacode.org/wiki/Jump_anywhere
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

DEF FN FuncHello$(msg$)
    [sub:inside] ' This label exists only inside FuncHello$
    ' GOTO/GOSUB [inits] would produce error since it does not exists inside FuncHello$
    RETURN "From FuncHello$: " + msg$
END DEF

[inits]
    LET hello$ = "[sub:hello2]"
    LET HELLO# = "[sub:hello2]"


[main]
    PRINT "Jumping to [sub:hello1] with strict style..."
    GOTO [sub:hello1]
    [ret:hello1]

    PRINT "Now GOSUB to [sub:hello2] via variable 'hello$'..."
    GOSUB hello$

    PRINT "And GOSUB to [sub:hello2] via CONSTANT 'HELLO#'..."
    GOSUB HELLO#

    PRINT FN FuncHello$("Function calling...")

    ' Line numbers supported, unless you do it in pretty akward way
    GOSUB [1]

    ' GOTO / GOSUB [sub:inside] would produce error, since it exists only inside FuncHello$
END


[sub:hello1]
    PRINT "Greets from [sub:hello1]"
GOTO [ret:hello1]


[sub:hello2]
    PRINT "Greets from [sub:hello2]"
RETURN


[1]
    PRINT "Inside [1]"
RETURN

' Output:
' Jumping to [sub:hello1] with strict style...
' Greets from [sub:hello1]
' Now GOSUB to [sub:hello2] via variable 'hello$'...
' Greets from [sub:hello2]
' And GOSUB to [sub:hello2] via CONSTANT 'HELLO#'...
' Greets from [sub:hello2]
' From FuncHello$: Function calling...
' Inside [1]
