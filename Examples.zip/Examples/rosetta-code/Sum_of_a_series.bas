' ============================================
' https://rosettacode.org/wiki/Sum_of_a_series
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
	LET N# = 1000
	LET sum$ = 0

[main]
	FOR k$ = 1 TO N#
		sum$+= 1 / POW(k$, 2)
	NEXT
	PRINT "s(1000) = "; sum$
	PRINT "zeta(2) = "; POW(PI#, 2) / 6
END

' Expected output:
' s(1000) = 1.6439345666815597
' zeta(2) = 1.6449340668482264