' ============================================
' https://rosettacode.org/wiki/Terminal_control/Ringing_the_terminal_bell
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET BELL# = CHR(7)

[main]
    PRINT BELL#
END
