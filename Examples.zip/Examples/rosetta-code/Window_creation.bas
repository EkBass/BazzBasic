' ============================================
' https://rosettacode.org/wiki/Window_creation
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
[inits]
	LET TITLE# = "Hello, Window!"
	LET running$

[init:gfx]
	SCREEN 0, 640, 480, TITLE#

[main]
    ' KEY_ESC# returned from "x" since ver. 1.1e
	running$ = WAITKEY(KEY_ESC#)
END