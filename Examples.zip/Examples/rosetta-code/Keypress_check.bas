' ============================================
' https://rosettacode.org/wiki/Keyboard_input/Keypress_check
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET key$ = 0

[main]
    ' loop until any key pressed
    WHILE key$ = 0
        key$ = INKEY
        SLEEP 5 ' small delay
    WEND

    ' Could use WAITKEY() but task description requires a way which wont pause program
    PRINT key$
END
