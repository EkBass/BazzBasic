' ============================================
' https://rosettacode.org/wiki/Letter_frequency
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' INSTRUCTIONS:
' Save this code as "Letter_frequency.bas" so it reads itself.

[inits]
    LET content$  = FileRead("Letter_frequency.bas")
    LET length$   = LEN(content$)
    LET char$
    LET code$
    DIM counts$

[main]
    ' Initialize counters A-Z
    FOR i$ = 65 TO 90
        counts$(CHR(i$)) = 0
    NEXT

    ' Count letters
    FOR i$ = 1 TO length$
        char$ = UCASE(MID(content$, i$, 1))
        code$ = ASC(char$)
        IF code$ >= 65 AND code$ <= 90 THEN
            counts$(char$) = counts$(char$) + 1
        ENDIF
    NEXT

[output]
    PRINT "Letter frequency in Letter_frequency.bas:"
    PRINT ""
    FOR i$ = 65 TO 90
        char$ = CHR(i$)
        PRINT char$; ": "; counts$(char$)
    NEXT
END

' Output:
' Letter frequency in Letter_frequency.bas:
' 
' A: 23
' B: 8
' C: 33
' D: 11
' E: 43
' F: 9
' G: 4
' H: 16
' I: 27
' J: 0
' K: 2
' L: 13
' M: 4
' N: 33
' O: 25
' P: 6
' Q: 3
' R: 27
' S: 20
' T: 50
' U: 14
' V: 0
' W: 1
' X: 3
' Y: 3
' Z: 6
