' ============================================
' https://rosettacode.org/wiki/Convert_seconds_to_compound_duration
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' Time-unit constants — accessible inside DEF FN via # scope
LET WEEK#   = 604800   ' 7 * 24 * 60 * 60
LET DAY#    =  86400   '     24 * 60 * 60
LET HOUR#   =   3600   '          60 * 60
LET MINUTE# =     60

DEF FN Duration$(total$)
    LET w$      = FLOOR(total$ / WEEK#)
    LET remain$ = total$ - w$ * WEEK#
    LET d$      = FLOOR(remain$ / DAY#)
    remain$     = remain$ - d$ * DAY#
    LET h$      = FLOOR(remain$ / HOUR#)
    remain$     = remain$ - h$ * HOUR#
    LET m$      = FLOOR(remain$ / MINUTE#)
    LET s$      = remain$ - m$ * MINUTE#
    LET out$    = ""

    IF w$ > 0 THEN
        out$ = STR(CINT(w$)) + " wk"
    END IF
    IF d$ > 0 THEN
        IF out$ <> "" THEN
            out$ = out$ + ", "
        END IF
        out$ = out$ + STR(CINT(d$)) + " d"
    END IF
    IF h$ > 0 THEN
        IF out$ <> "" THEN
            out$ = out$ + ", "
        END IF
        out$ = out$ + STR(CINT(h$)) + " hr"
    END IF
    IF m$ > 0 THEN
        IF out$ <> "" THEN
            out$ = out$ + ", "
        END IF
        out$ = out$ + STR(CINT(m$)) + " min"
    END IF
    IF s$ > 0 THEN
        IF out$ <> "" THEN
            out$ = out$ + ", "
        END IF
        out$ = out$ + STR(CINT(s$)) + " sec"
    END IF

    IF out$ = "" THEN RETURN "0 sec"
    RETURN out$
END DEF

[tests]
    PRINT "7259    -> "; FN Duration$(7259)
    PRINT "86400   -> "; FN Duration$(86400)
    PRINT "6000000 -> "; FN Duration$(6000000)
    PRINT "0       -> "; FN Duration$(0)
    PRINT ""

[userinput]
    INPUT "Seconds (0 to quit): ", sec$
    IF sec$ = 0 THEN GOTO [done]
    PRINT FN Duration$(sec$)
    PRINT ""
    GOTO [userinput]

[done]
END

' Output:
' 7259    -> 2 hr, 59 sec
' 86400   -> 1 d
' 6000000 -> 9 wk, 6 d, 10 hr, 40 min
' 0       -> 0 sec
