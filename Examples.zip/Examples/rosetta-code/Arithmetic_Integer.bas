' ============================================
' https://rosettacode.org/wiki/Arithmetic/Integer
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[main]
    ' Works also if separated with whitespace instead of comma
    INPUT "Enter two integers separated by a comma: ", a$, b$
    a$ = INT(VAL(a$))
    b$ = INT(VAL(b$))
[output]
    PRINT "Sum:        "; a$ + b$
    PRINT "Difference: "; a$ - b$
    PRINT "Product:    "; a$ * b$
    PRINT "Quotient:   "; INT(a$ / b$)
    PRINT "Remainder:  "; MOD(a$, b$)
    PRINT "Power:      "; POW(a$, b$)
END

' Output 1:
' Enter two integers separated by a comma: 3,5
' Sum:        8
' Difference: -2
' Product:    15
' Quotient:   0
' Remainder:  3
' Power:      243