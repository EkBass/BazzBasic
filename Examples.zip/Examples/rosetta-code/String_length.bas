' ============================================
' https://rosettacode.org/wiki/String_length
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
' Find the character (LEN) and byte (UTF-8) length
' of a string.
'
' BazzBasic runs on .NET, so strings are UTF-16
' internally and ASC() returns the full Unicode
' code point. UTF-8 byte length is computed
' manually from those code points.
' ============================================

DEF FN Utf8ByteLen$(s$)
    LET bytes$ = 0
    FOR i$ = 1 TO LEN(s$)
        LET cp$ = ASC(MID(s$, i$, 1))
        IF cp$ < 128 THEN
            bytes$+= 1         ' U+0000 – U+007F  : 1 byte
        ELSEIF cp$ < 2048 THEN
            bytes$+= 2         ' U+0080 – U+07FF  : 2 bytes
        ELSEIF cp$ < 65536 THEN
            bytes$+= 3         ' U+0800 – U+FFFF  : 3 bytes
        ELSE
            bytes$+= 4         ' U+10000 –        : 4 bytes
        END IF
    NEXT
    RETURN bytes$
END DEF

[main]
    DIM tests$
    tests$(0) = "Hello"             ' pure ASCII
    tests$(1) = "møøse"             ' Latin Extended  (ø = U+00F8, 2 bytes each)
    tests$(2) = "Ελληνικά"          ' Greek           (3 bytes each)
    tests$(3) = "日本語"             ' CJK             (3 bytes each)
    tests$(4) = "𝄞"                 ' Musical symbol  (U+1D11E, 4 bytes)

    PRINT REPEAT("-", 46)
    PRINT " String              Chars    Bytes (UTF-8)"
    PRINT REPEAT("-", 46)

    FOR i$ = 0 TO 4
        LET s$     = tests$(i$)
        LET chars$ = LEN(s$)
        LET bytes$ = FN Utf8ByteLen$(s$)
        PRINT " "; LEFT(s$ + REPEAT(" ", 20), 20); chars$; "        "; bytes$
    NEXT

    PRINT REPEAT("-", 46)
END

' Output:
' ----------------------------------------------
'  String              Chars    Bytes (UTF-8)
' ----------------------------------------------
'  Hello               5        5
'  møøse               5        7
'  Ελληνικά            8        16
'  日本語                3        9
'  𝄞                   1        4
' ----------------------------------------------
