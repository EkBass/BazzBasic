' ============================================
' https://rosettacode.org/wiki/Variable_size/Get
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' BazzBasic is a typeless language — every variable holds any value
' (numeric or string) and has no fixed byte size to query.
' The relevant size operations are:
'   LEN(s$)      — number of characters in a string
'   LEN(arr$())  — number of elements in an array  (note the empty parens)

[inits]
    LET greeting$ = "Hello, World!"
    LET pi$       = 3.14159
    LET empty$    = ""

    DIM items$
    items$(0) = "apple"
    items$(1) = "banana"
    items$(2) = "cherry"

[main]
    ' String length
    PRINT "greeting$ = \"" + greeting$ + "\""
    PRINT "LEN(greeting$) = " + STR(LEN(greeting$))
    PRINT ""

    PRINT "pi$ = " + STR(pi$)
    PRINT "LEN(STR(pi$)) = " + STR(LEN(STR(pi$)))
    PRINT ""

    PRINT "empty$ = \"\""
    PRINT "LEN(empty$) = " + STR(LEN(empty$))
    PRINT ""

    ' Array element count
    PRINT "items$ has " + STR(LEN(items$())) + " elements"
END

' Output:
' greeting$ = "Hello, World!"
' LEN(greeting$) = 13
'
' pi$ = 3.14159
' LEN(STR(pi$)) = 7
'
' empty$ = ""
' LEN(empty$) = 0
'
' items$ has 3 elements
