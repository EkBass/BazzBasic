' ============================================
' https://rosettacode.org/wiki/Execute_Brain****
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET MEM_SIZE# = 1000
    DIM mem$
    LET ptr$ = 0
    LET pc$   = 1
    LET op$, ch$, inp$
    LET codeLen$, depth$

    ' Hello World
    LET code$ = "++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++."

    FOR i$ = 0 TO MEM_SIZE# - 1
        mem$(i$) = 0
    NEXT

[main]
    codeLen$ = LEN(code$)

    WHILE pc$ <= codeLen$
        op$ = MID(code$, pc$, 1)

        IF op$ = ">" THEN
            ptr$ = ptr$ + 1
            IF ptr$ >= MEM_SIZE# THEN ptr$ = 0
        END IF

        IF op$ = "<" THEN
            ptr$ = ptr$ - 1
            IF ptr$ < 0 THEN ptr$ = MEM_SIZE# - 1
        END IF

        IF op$ = "+" THEN
            mem$(ptr$) = mem$(ptr$) + 1
            IF mem$(ptr$) > 255 THEN mem$(ptr$) = 0
        END IF

        IF op$ = "-" THEN
            mem$(ptr$) = mem$(ptr$) - 1
            IF mem$(ptr$) < 0 THEN mem$(ptr$) = 255
        END IF

        IF op$ = "." THEN PRINT CHR(mem$(ptr$));

        IF op$ = "," THEN
            INPUT "", inp$
            IF LEN(inp$) > 0 THEN
                mem$(ptr$) = ASC(inp$)
            ELSE
                mem$(ptr$) = 0
            END IF
        END IF

        IF op$ = "[" THEN
            IF mem$(ptr$) = 0 THEN
                depth$ = 1
                WHILE depth$ > 0
                    pc$ = pc$ + 1
                    ch$ = MID(code$, pc$, 1)
                    IF ch$ = "[" THEN depth$+= 1
                    IF ch$ = "]" THEN depth$-= 1
                WEND
            END IF
        END IF

        IF op$ = "]" THEN
            IF mem$(ptr$) <> 0 THEN
                depth$ = 1
                WHILE depth$ > 0
                    pc$ = pc$ - 1
                    ch$ = MID(code$, pc$, 1)
                    IF ch$ = "]" THEN depth$+= 1
                    IF ch$ = "[" THEN depth$-= 1
                WEND
            END IF
        END IF

        pc$+= 1
    WEND

' Output:
' Hello World!