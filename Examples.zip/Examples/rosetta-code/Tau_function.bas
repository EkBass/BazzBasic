' ============================================
' https://rosettacode.org/wiki/Tau_function
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
[inits]
	LET t$ = 0

[main]
	FOR n$ = 1 TO 100
		IF n$ < 3 THEN
			t$ = n$
		ELSE
			t$ = 2
			FOR a$ = 2 TO INT((n$ + 1) / 2)
				IF MOD(n$, a$) = 0 THEN t$+= 1
			NEXT
		END IF
		PRINT t$; " ";
		IF MOD(n$, 10) = 0 THEN PRINT ""
	NEXT
END

' Expected output:
' 1 2 2 3 2 4 2 4 3 4
' 2 6 2 4 4 5 2 6 2 6
' 4 4 2 8 3 4 4 6 2 8
' 4 6 4 4 4 9 2 4 4 8
' 2 8 4 6 4 4 2 10 4 6
' 4 8 2 8 4 4 4 8 2 12
' 4 4 6 7 2 8 4 8 4 8
' 2 12 4 6 4 10 2 8 4 8
' 6 4 2 12 4 6 4 8 2 12
' 6 4 6 8 4 8 4 6 3 9