' ============================================
' https://rosettacode.org/wiki/Mouse_position
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' BazzBasic requires graphics screen to work with mouse
[inits]
    SCREEN 0, 800, 600, "Mouse_position.bas"

[main]
    WHILE INKEY <> KEY_ESC#
        LOCATE 1, 1
        PRINT "X:"; MOUSEX; " Y:"; MOUSEY; "   "
		SLEEP 5
    WEND
END
