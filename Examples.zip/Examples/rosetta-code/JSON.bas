' ============================================
' https://rosettacode.org/wiki/JSON
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
	DIM person$
	' Build a structure to be encoded to JSON
    person$("name")         = "Alice"
    person$("age")          = 30
    person$("address,city") = "New York"
    person$("hobbies,0")    = "reading"
    person$("hobbies,1")    = "coding"
    
	' decoded
	DIM decoded$
	
	' variable for JSON
	LET json$
	
[asjson]
	' ASJSON does the magic with one keyword
	json$ = ASJSON(person$)
	PRINT "Encoded:"
	PRINT json$

[asarray]
	' Decode JSON back to array
	LET count$ = ASARRAY(decoded$, json$)
	PRINT ""
	PRINT "Decoded:"
	PRINT "Name:    "; decoded$("name")
	PRINT "Age:     "; decoded$("age")
	PRINT "City:    "; decoded$("address,city")
	PRINT "Hobby 1: "; decoded$("hobbies,0")
	PRINT "Hobby 2: "; decoded$("hobbies,1")
END

' Output:
' Encoded:
' {"name":"Alice","age":30,"address":{"city":"New York"},"hobbies":["reading","coding"]}

' Decoded:
' Name:    Alice
' Age:     30
' City:    New York
' Hobby 1: reading
' Hobby 2: coding
