' ============================================
' https://rosettacode.org/wiki/Metaprogramming
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
' BazzBasic does not support macros or AST manipulation.
' Instead, it provides two practical metaprogramming-style tools:
'
' 1. INCLUDE — source composition at load time
'    INCLUDE "file.bas" inserts the contents of that file before execution.
'    This allows modular programs (constants, functions, subs).
'    INCLUDE also supports compiled libraries:
'      INCLUDE "MathLib.bb"
'
' 2. Dynamic GOTO / GOSUB — runtime label dispatch
'    Labels are strings in the form "[label]".
'    A variable can hold such a string, enabling indirect jumps.
'    This acts like a simple dispatch table (similar to function pointers).
' --------------------------------------------------

[inits]
    LET GREETING# = "[sub:hello]"
    LET FAREWELL# = "[sub:bye]"
    LET dispatch$

[main]
    dispatch$ = GREETING#
    GOSUB dispatch$
    dispatch$ = FAREWELL#
    GOSUB dispatch$
END

[sub:hello]
    PRINT "Hello from a dynamically dispatched subroutine."
RETURN

[sub:bye]
    PRINT "Goodbye — label chosen at runtime."
RETURN

' --------------------------------------------------
' Notes
' --------------------------------------------------
' - Labels MUST include brackets: "[label]"
' - If the label does not exist, GOSUB/GOTO causes a runtime error
'
' Example of failure:
'   LET dispatch$ = "[does_not_exist]"
'   GOSUB dispatch$    ' ERROR: label not found
'
' This pattern replaces long IF/ELSEIF chains with a clean dispatch system.
'
' Conceptual extension — dispatch table via array:
'   commands$("hello") = "[sub:hello]"
'   commands$("bye")   = "[sub:bye]"
'   dispatch$ = commands$(userInput$)
'   GOSUB dispatch$
' --------------------------------------------------
' Output:
' Hello from a dynamically dispatched subroutine.
' Goodbye — label chosen at runtime.
