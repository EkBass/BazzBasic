' ============================================
' https://rosettacode.org/wiki/Loops/Infinite
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' BazzBasic supports infinite loops in two natural ways.

' --- Method 1: WHILE TRUE ---

[main]
    WHILE TRUE
        PRINT "SPAM"
    WEND

' --- Method 2: GOTO ---
'
' [main]
'     PRINT "SPAM"
' GOTO [main]

' Output (infinite):
' SPAM
' SPAM
' SPAM
' ...
