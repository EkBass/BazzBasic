' ============================================
' https://rosettacode.org/wiki/Generic_swap
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET a$ = 1
    LET b$ = 2

    LET c$ = "Bazz"
    LET d$ = "Basic"

[main]
    ' swap inits
    PRINT "# Numbers"
    PRINT "\n## Before swap"
    PRINT "\ta$ = "; a$
    PRINT "\tb$ = "; b$


    a$+= b$         ' a$ = 3
    b$-= a$ - b$    ' b$ = 1
    a$-= b$         ' a$ = 2

    PRINT "\n## After swap"
    PRINT "\ta$ = "; a$
    PRINT "\tb$ = "; b$

    ' swap strings
    PRINT "\n# Strings"
    PRINT "\n## Before swap"
    PRINT "\tc$ = "; c$
    PRINT "\td$ = "; d$


    c$+= d$                                ' c$ = BazzBasic
    d$ = LEFT(c$, LEN(c$) - LEN(d$))       ' d$ = Bazz
    c$ = RIGHT(c$, LEN(c$) - LEN(d$))      ' c$ = Basic

    PRINT "\n## After swap"
    PRINT "\tc$ = "; c$
    PRINT "\td$ = "; d$
END

' Output:
' # Numbers
' 
' ## Before swap
'         a$ = 1
'         b$ = 2
' 
' ## After swap
'         a$ = 2
'         b$ = 1
' # Strings
' 
' ## Before swap
'         c$ = Bazz
'         d$ = Basic
' 
' ## After swap
'         c$ = Basic
'         d$ = Bazz