' ============================================
' https://rosettacode.org/wiki/Animation
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    SCREEN 0, 400, 200, "Animation"
    LET txt$      = "Hello World! "
    LET dir$      = TRUE
    LET prevClick$ = FALSE
    LET clicked$

[main]
    WHILE INKEY <> KEY_ESC#

        ' Edge-trigger: flip direction only on fresh click
        clicked$ = MOUSERIGHT
        IF clicked$ AND NOT prevClick$ THEN dir$ = NOT dir$
        prevClick$ = clicked$

        ' Rotate text
        IF dir$ THEN
            txt$ = RIGHT(txt$, 1) + LEFT(txt$, LEN(txt$) - 1)
        ELSE
            txt$ = MID(txt$, 2) + LEFT(txt$, 1)
        ENDIF

        LOCATE 5, 10
        PRINT txt$

        SLEEP 200
    WEND
END
