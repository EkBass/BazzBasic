' ============================================
' Visualize a tree
' https://rosettacode.org/wiki/Visualize_a_tree#FreeBASIC
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

DEF FN GetHeaderLevel$(l$)
    LET c$ = 0
    ' Check if the line starts with a hash
    IF LEFT(l$, 1) <> "#" THEN RETURN 0
    
    ' Count hashes
    WHILE MID(l$, c$ + 1, 1) = "#"
        c$ += 1
    WEND
    RETURN c$
END DEF

[inits]
    DIM lines$
    LET tab$ = CHR(9)
    LET currentIndent$ = ""
    LET result$ = ""
    LET lvl$ = 0, numLines$ = 0
    
    LET exampleCode$ = "# Header 1\n\nFoo bar, this is text\n\n## Header 2\n\nFoo bar, this is text\n\n### Header 3\n\nFoo bar, this is text\n\n## Header 2.2\n\nFoo bar, this is text\n\n### Header 3.2\n\nFoo bar, this is text\n\n# Header 1.2\n\nFoo bar, this is text"

[main]
    numLines$ = SPLIT(lines$, exampleCode$, "\n")
    
    FOR i$ = 0 TO ROWCOUNT(lines$()) - 1
        ' Check if starts with "#"
        lvl$ = FN GetHeaderLevel$(lines$(i$))
        
        IF lvl$ > 0 THEN
            currentIndent$ = REPEAT(tab$, lvl$ - 1)
        END IF
        
        result$ = result$ + currentIndent$ + lines$(i$) + "\n"
    NEXT

[output]
    CLS
    PRINT "Result:"
    PRINT result$
END

' Output:
' Result:
' # Header 1
' 
' Foo bar, this is text
' 
'         ## Header 2
' 
'         Foo bar, this is text
' 
'                 ### Header 3
' 
'                 Foo bar, this is text
' 
'         ## Header 2.2
' 
'         Foo bar, this is text
' 
'                 ### Header 3.2
' 
'                 Foo bar, this is text
' 
' # Header 1.2
' 
' Foo bar, this is text