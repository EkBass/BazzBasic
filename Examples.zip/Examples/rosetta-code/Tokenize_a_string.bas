' ============================================
' https://rosettacode.org/wiki/Tokenize_a_string
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    DIM tokens$

    LET SEP#    = ","
    LET list$   = "Hello,How,Are,You,Today"
    LET count$

[main]
    ' SPLIT() is handy, since fills the array (tokens$) and returns the amount at same call.
    LET count$ = SPLIT(tokens$, list$, SEP#)

[out]
    FOR i$ = 0 TO count$ - 1
        PRINT tokens$(i$); ".";
    NEXT
END

' Output:
' Hello.How.Are.You.Today.
