' ============================================
' Sort_three_variables
' https://rosettacode.org/wiki/Sort_three_variables
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET a$ = RND(100)
    LET b$ = RND(100)
    LET c$ = RND(100)

[main]

    PRINT "Start:"
    PRINT "a$: "; a$
    PRINT "b$: "; b$
    PRINT "c$: "; c$
    
    ' preserve the sum with out temp var
    a$ = a$ + b$ + c$

    ' re-construct the original value of a$
    c$ = MAX(a$ - b$ - c$, MAX(b$, c$))

    ' Sum of all three - Max - Min = Middle
    b$ = (a$ - c$) - MIN(a$ - b$ - c$, MIN(b$, c$))

    ' Total Sum - Max - Mid = Min
    a$ = a$ - c$ - b$

[output]
    PRINT "Sorted Order:"
    PRINT "a$: "; a$
    PRINT "b$: "; b$
    PRINT "c$: "; c$
END

' Output
' Start:
' a$: 77
' b$: 59
' c$: 74
' Sorted Order:
' a$: 59
' b$: 74
' c$: 77