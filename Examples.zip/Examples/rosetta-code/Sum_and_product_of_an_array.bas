' ============================================
' https://rosettacode.org/wiki/Sum_and_product_of_an_array
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    DIM myArray$
    LET sum$ = 0
    LET prod$ = 1

[fill-array]
    FOR i$ = 0 TO 9
        myArray$(i$) = i$ + 1
    NEXT

[main]
    FOR i$ = 0 TO ROWCOUNT(myArray$()) - 1
        sum$+= myArray$(i$)
        prod$*= myArray$(i$)
    NEXT

[output]
    PRINT "Sum of array: "; sum$
    PRINT "Product of array: "; prod$
END

' Output:
' Sum of array: 55
' Product of array: 3628800
