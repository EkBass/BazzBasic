' ============================================
' https://rosettacode.org/wiki/Terminal_control/Cursor_positioning
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET ver$

[output]
    CLS
    LOCATE 6, 3 : PRINT "Hello"

[verify]
    ver$ = GETCONSOLE(6, 3, 0) ' Returns char at row 6, col 3 as ASCII code
    LOCATE 10, 1
    PRINT "Char at row 6, col 3 is: "; CHR(ver$)
END
