' ============================================
' https://rosettacode.org/wiki/Ascending_primes
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' Strategy: every number with strictly ascending digits corresponds
' to a unique non-empty subset of {1..9}.
' There are 2^9 - 1 = 511 such subsets — far fewer than testing all
' primes up to 123,456,789.
' For each bitmask 1..511 the digits are the set bits (bit k → digit k+1),
' assembled left-to-right to form the candidate number.

DEF FN IsPrime$(n$)
    IF n$ < 2 THEN RETURN 0
    IF n$ = 2 THEN RETURN 1
    IF MOD(n$, 2) = 0 THEN RETURN 0
    LET i$ = 3
    WHILE i$ * i$ <= n$
        IF MOD(n$, i$) = 0 THEN RETURN 0
        i$ = i$ + 2
    WEND
    RETURN 1
END DEF

[inits]
    DIM results$
    LET count$ = 0
    LET mask$, digit$, power$, bit$, num$
    LET si$, sj$, tmp$

[main]
    FOR mask$ = 1 TO 511
        num$ = 0
        FOR digit$ = 1 TO 9
            power$ = POW(2, digit$ - 1)
            bit$ = MOD(INT(mask$ / power$), 2)
            IF bit$ = 1 THEN num$ = num$ * 10 + digit$
        NEXT
        IF FN IsPrime$(num$) THEN
            results$(count$) = num$
            count$ = count$ + 1
        END IF
    NEXT

    ' Bubble sort — only ~36 elements, so cost is negligible
    FOR si$ = 0 TO count$ - 2
        FOR sj$ = 0 TO count$ - si$ - 2
            IF results$(sj$) > results$(sj$ + 1) THEN
                tmp$ = results$(sj$)
                results$(sj$) = results$(sj$ + 1)
                results$(sj$ + 1) = tmp$
            END IF
        NEXT
    NEXT

    PRINT "Primes with strictly ascending digits (" + STR(count$) + " total):"
    FOR si$ = 0 TO count$ - 1
        PRINT results$(si$); " ";
    NEXT
    PRINT ""
END

' Output:
' Primes with strictly ascending digits (36 total):
' 2 3 5 7 13 17 19 23 29 37 47 59 67 79 89 127 137 139 149 157 167 179 239 257
' 269 347 349 359 367 379 389 457 467 479 569 
