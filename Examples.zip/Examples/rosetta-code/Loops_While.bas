' ============================================
' https://rosettacode.org/wiki/Loops/While
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET value$ = 1024

[main]
    WHILE value$ > 0
        PRINT value$
        value$ = INT(value$ / 2)
    WEND
END

' Output:
' 1024
' 512
' 256
' 128
' 64
' 32
' 16
' 8
' 4
' 2
' 1
