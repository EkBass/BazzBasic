' ============================================
' Special variables
' https://rosettacode.org/wiki/Special_variables
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================


' Returns the Euler's constant, 2.718281828459045
PRINT EULER#

' Returns half of π (pi/2) ≈ 1.5707963267948966. Equivalent to 90 degrees in radians.
PRINT HPI#

' Returns the mathematical constant π (pi) ≈ 3.14159265358979.
PRINT PI#

' Returns a quarter of π (pi/4) ≈ 0.7853981633974475. Equivalent to 45 degrees in radians.
PRINT QPI#

' Returns τ (tau) = 2π ≈ 6.28318530717958. Equivalent to 360 degrees in radians (a full circle).
PRINT TAU#

' FALSE and OFF are 0
PRINT FALSE
PRINT OFF   ' examples in VSYNC

' TRUE and ON are 1
PRINT TRUE
PRINT ON    ' examples in VSYNC

' Returns version of BazzBasic in use
PRINT BBVER#

' Program base directory path
PRINT PRG_ROOT#

' Almost every key has its own constant
PRINT KEY_ESC#
PRINT KEY_F12#

' See full list: https://ekbass.github.io/BazzBasic/manual/#/keywords?id=keyboard-constants