' ============================================
' https://rosettacode.org/wiki/Reverse_a_string
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
' INVERT reverses both strings and numbers.

[inits]
    LET alpha$ = "abcdefg..."     ' variable
    LET NUM#   = 12345            ' constant

[main]
    PRINT INVERT(alpha$)
    PRINT INVERT(NUM#)
END

' Output:
' ...gfedcba
' 54321
