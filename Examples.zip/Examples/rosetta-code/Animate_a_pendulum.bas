' https://rosettacode.org/wiki/Animate_a_pendulum
' BazzBasic conversion from Freebasic code
' https://ekbass.github.io/BazzBasic/

' This is done for educational purposes -> commented everything
' Public Domain


[init]
    LET SCREEN_W# = 640         ' Screen width in pixels
    LET SCREEN_H# = 480         ' Screen height in pixels
    LET DAMPING# = 0.9995       ' Energy loss per frame (1.0 = no loss, 0.0 = instant stop)

    LET g$      = 9.81          ' Gravity constant (m/s²) — drives the swing force
    LET l$      = 1             ' Pendulum length (affects swing speed — longer = slower)
    LET speed$  = 0             ' Current angular velocity (how fast the angle is changing)
    LET accel$                  ' Angular acceleration this frame (force pushing toward center)

    LET px$     = SCREEN_W# / 2 ' Pivot point X — where the pendulum is attached (screen center top)
    LET py$     = 10            ' Pivot point Y — a bit down from top edge
    LET theta$  = HPI#           ' Current angle in radians (HPI = 90° = starts horizontal)
    LET bx$                     ' Bob X position on screen (calculated each frame)
    LET by$                     ' Bob Y position on screen (calculated each frame)


[main]
    SCREEN SCREEN_W#, SCREEN_H#
    WHILE INKEY <> KEY_ESC#
        ' Project angle to screen coordinates
        bx$ = px$ + l$ * (SCREEN_W# / 2) * SIN(theta$)   ' horizontal offset from pivot
        by$ = py$ - l$ * (SCREEN_W# / 2) * COS(theta$)   ' vertical offset from pivot (Y flipped)

        SCREENLOCK ON
            LINE (0, 0) - (SCREEN_W#, SCREEN_H#), 15, BF   ' clear screen
            LINE (px$, py$) - (bx$, by$), 0                ' draw rod
            CIRCLE (bx$, by$), 50, 7, 1                    ' draw bob
        SCREENLOCK OFF

        accel$  = g$ * SIN(theta$) / l$ / 100  ' gravity pulls bob toward center (SIN of angle = sideways force)
        speed$  = (speed$ * DAMPING#) + accel$ / 100  ' update speed with damping applied
        theta$  = theta$ + speed$              ' advance the angle by current speed
        SLEEP 16
    WEND
END
