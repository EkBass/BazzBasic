' ============================================
' https://rosettacode.org/wiki/Loops/Downward_for
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[main]
    FOR i$ = 10 TO 0 STEP -1
        PRINT i$
    NEXT
END

' Output:
' 10
' 9
' 8
' 7
' 6
' 5
' 4
' 3
' 2
' 1
' 0
