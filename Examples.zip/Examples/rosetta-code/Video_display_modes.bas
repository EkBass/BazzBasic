' ============================================
' https://rosettacode.org/wiki/Video_display_modes
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' BazzBasic opens and switches graphics screens with the SCREEN command.
'
' Named modes (SDL2 window):
'   SCREEN 1          320 x 200
'   SCREEN 2          640 x 350
'   SCREEN 7          320 x 200
'   SCREEN 9          640 x 350
'   SCREEN 12         640 x 480  (recommended default)
'   SCREEN 13         320 x 200
'
' Custom size:
'   SCREEN 0, w, h
'   SCREEN 0, w, h, "Window title"
'
' Fullscreen toggle (borderless, graphics mode only):
'   FULLSCREEN TRUE
'   FULLSCREEN FALSE
'
' Calling SCREEN again switches to the new mode immediately.

[inits]
    LET key$

[main]
    ' ── Custom 800 x 600 ────────────────────────────────────
    SCREEN 0, 800, 600, "BazzBasic — 800x600"
    SCREENLOCK ON
        COLOR 10, 0
        LOCATE 2, 2 : PRINT "Custom mode — 800 x 600"
        COLOR 7, 0
        LOCATE 4, 2 : PRINT "SCREEN 0, w, h, title  opens any arbitrary size."
        LOCATE 6, 2 : PRINT "Press any key to enter fullscreen ..."
    SCREENLOCK OFF
    key$ = WAITKEY()

    ' ── Fullscreen (borderless) ──────────────────────────────
    FULLSCREEN TRUE
    SCREENLOCK ON
        LINE (0,0)-(800,600), 0, BF
        COLOR 13, 0
        LOCATE 2, 2 : PRINT "Fullscreen mode  (borderless)"
        COLOR 7, 0
        LOCATE 4, 2 : PRINT "FULLSCREEN TRUE  — fills the display."
        LOCATE 5, 2 : PRINT "FULLSCREEN FALSE — returns to windowed."
        LOCATE 7, 2 : PRINT "Press any key to exit ..."
    SCREENLOCK OFF
    key$ = WAITKEY()

    FULLSCREEN FALSE
END
