' ============================================
' https://rosettacode.org/wiki/Repeat_a_string
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET string$ = "Hello"
    LET times$  = 5

[main]
    PRINT REPEAT(string$, times$)
END

' Output:
' HelloHelloHelloHelloHello