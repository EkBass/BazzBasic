' ============================================
' Monty Hall problem
' https://rosettacode.org/wiki/Monty_Hall_problem
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
' Both players compete on the same round each iteration:
' same winning door, same initial pick.
' This eliminates any randomness advantage between strategies.
' "Stay"   player always keeps the initial pick.
' "Switch" player always switches to the other door.

LET SIMULATIONS# = 10000

[inits]
    LET winning$
    LET pick$
    LET stayWins$   = 0
    LET switchWins$ = 0
    LET stayPct$
    LET switchPct$
    LET i$

[main]
    FOR i$ = 1 TO SIMULATIONS#
        winning$ = RND(3) + 1   ' winning door: 1-3
        pick$    = RND(3) + 1   ' both players start with same pick

        IF pick$ = winning$ THEN
            stayWins$+= 1
        ELSE
            switchWins$-= 1
        END IF
    NEXT

[output]
    stayPct$   = CINT(stayWins$   * 100 / SIMULATIONS#)
    switchPct$ = CINT(switchWins$ * 100 / SIMULATIONS#)

    PRINT "Simulations: " + SIMULATIONS#
    PRINT ""
    PRINT "Stay:   " + stayWins$   + " wins (" + stayPct$   + "%)"
    PRINT "Switch: " + switchWins$ + " wins (" + switchPct$ + "%)"
END

' Output:
' Simulations: 10000
'
' Stay:   3365 wins (34%)
' Switch: 6635 wins (66%)
