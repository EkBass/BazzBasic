' ============================================
' https://rosettacode.org/wiki/Modular_arithmetic
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

' BazzBasic does not support operator overloading.
' Instead, modular ring operations are expressed as functions.
' F$ evaluates f(x) = x^100 + x + 1 within the ring Z/mZ,
' staying transparent to the choice of modulus.

DEF FN ModPow$(base$, exp$, m$)
    ' Computes (base ^ exp) mod m via repeated multiplication.
    ' Keeps intermediate values small — avoids overflow for large exponents.
    LET result$ = 1
    LET b$ = MOD(base$, m$)
    FOR i$ = 1 TO exp$
        result$ = MOD(result$ * b$, m$)
    NEXT
    RETURN result$
END DEF

DEF FN F$(x$, m$)
    ' f(x) = x^100 + x + 1, evaluated in Z/mZ.
    ' Each operation is reduced modulo m — the function is ring-agnostic.
    LET xp$ = FN ModPow$(x$, 100, m$)
    RETURN MOD(xp$ + MOD(x$, m$) + 1, m$)
END DEF

[inits]
    LET MODULUS# = 13
    LET X# = 10
    LET result$

[main]
    result$ = FN F$(X#, MODULUS#)
    PRINT "f(x) = x^100 + x + 1"
    PRINT "x = " + STR(X#) + ",  modulus = " + STR(MODULUS#)
    PRINT "f(" + STR(X#) + ") mod " + STR(MODULUS#) + " = " + STR(result$)
END

' Output:
' f(x) = x^100 + x + 1
' x = 10,  modulus = 13
' f(10) mod 13 = 1
