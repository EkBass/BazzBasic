' ============================================
' https://rosettacode.org/wiki/Write_entire_file
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET FILENAME# = "output.txt"
    LET output$ = "Mickey Mouse"

[main]
    FILEWRITE FILENAME#, output$
END

' Output: 
' file: "output.txt" containing "Mickey Mouse"