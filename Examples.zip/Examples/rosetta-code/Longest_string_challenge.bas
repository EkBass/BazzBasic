' ============================================
' https://rosettacode.org/wiki/Longest_string_challenge
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
'
' Two different approaches.
'
'   Approach 1 - Classic: two passes over an array,
'                using LEN.
'
'   Approach 2 - Spirit of the challenge: no LEN,
'                no numeric length, no comparison of
'                string sizes as numbers. Lengths
'                are compared implicitly by stripping
'                one character from each candidate
'                per round and watching which one
'                empties first.
' ============================================

DEF FN Longer$(a$, b$)
    ' Returns:
    '   -1  if a$ is shorter than b$
    '    0  if a$ and b$ are the same length
    '    1  if a$ is longer than b$
    ' Does not use LEN.
    WHILE TRUE
        IF a$ = "" AND b$ = "" THEN RETURN 0
        IF a$ = "" THEN RETURN -1
        IF b$ = "" THEN RETURN 1
        a$ = MID(a$, 2)
        b$ = MID(b$, 2)
    WEND
END DEF

[inits]
    LET NL#     = CHR(10)
    LET source$ = "a" + NL# + "bb" + NL# + "ccc" + NL# + "ddd" + NL# + "ee" + NL# + "f" + NL# + "ggg"

    DIM words$
    LET count$   = SPLIT(words$, source$, NL#)

    LET longest$ = 0
    LET best$    = ""
    LET result$  = ""
    LET cmp$     = 0

[approach1]
    PRINT "[Approach 1 - LEN + two passes]"
    FOR i$ = 0 TO count$ - 1
        IF LEN(words$(i$)) > longest$ THEN longest$ = LEN(words$(i$))
    NEXT
    FOR i$ = 0 TO count$ - 1
        IF LEN(words$(i$)) = longest$ THEN PRINT words$(i$)
    NEXT

[approach2]
    PRINT ""
    PRINT "[Approach 2 - no LEN, chomp compare]"
    FOR i$ = 0 TO count$ - 1
        cmp$ = FN Longer$(words$(i$), best$)
        IF cmp$ = 1 THEN
            best$   = words$(i$)
            result$ = words$(i$) + NL#
        ELSEIF cmp$ = 0 THEN
            result$ = result$ + words$(i$) + NL#
        END IF
    NEXT
    PRINT result$;
END

' Output:
' # Approach 1 - LEN + two passes
' ccc
' ddd
' ggg
' 
' # Approach 2 - no LEN, chomp compare
' ccc
' ddd
' ggg