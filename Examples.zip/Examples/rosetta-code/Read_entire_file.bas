' ============================================
' https://rosettacode.org/wiki/Read_entire_file
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================

[inits]
    LET inputFile$ = "test.txt"
    LET content$

[main]
    ' Check if exists and if so, read it
    IF FILEEXISTS(inputFile$) = TRUE THEN

        ' FILEREAD() returns whole .txt file as string
        content$ = FILEREAD(inputFile$)
        PRINT "Content:\n"; content$
    ELSE
        PRINT "File: "; inputFile$; " do not exist."
    END IF
END

' OUTPUT:
' Content:
' The quick brown fox jumps over the lazy dog.
' Empty vessels make most noise.
' Too many chefs spoil the broth.
' A rolling stone gathers no moss.
