' ============================================
' Morse code
' https://rosettacode.org/wiki/Morse_code
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
' Encodes a text string into Morse code.
' Dots are "." and dashes are "_".
' Words are separated by " / ".
' Unknown characters are silently skipped.

DEF FN Encode$(text$, codes$)
    LET result$
    LET i$
    LET ch$
    LET pos$
    LET start$
    LET stop$
    FOR i$ = 1 TO LEN(text$)
        ch$ = UCASE(MID(text$, i$, 1))
        IF ch$ = " " THEN
            result$ = result$ + "/ "
        ELSE
            pos$ = INSTR(codes$, ch$ + ":")
            IF pos$ > 0 THEN
                start$ = pos$ + 2
                stop$ = INSTR(start$, codes$, ",")
                result$ = result$ + MID(codes$, start$, stop$ - start$) + " "
            END IF
        END IF
    NEXT
    RETURN TRIM(result$)
END DEF

[inits]
    LET morseCodes$
    LET input$
    LET encoded$
    morseCodes$ = "A:._,B:_...,C:_._.,D:_..,E:.,F:.._.,"
    morseCodes$ = morseCodes$ + "G:__.,H:....,I:..,J:.___,K:_._,L:._..,M:__,"
    morseCodes$ = morseCodes$ + "N:_.,O:___,P:.__.,Q:__._,R:._.,S:...,T:_,"
    morseCodes$ = morseCodes$ + "U:.._,V:..._,W:.__,X:_.._,Y:_.__,Z:__..,"
    morseCodes$ = morseCodes$ + "0:_____,1:.____,2:..___,3:...__,4:...._,"
    morseCodes$ = morseCodes$ + "5:.....,6:_....,7:__...,8:___..,9:____.,"

[main]
    LINE INPUT "Enter text: ", input$
    encoded$ = FN Encode$(input$, morseCodes$)
    PRINT "Morse: " + encoded$
END

' Output:
' Enter text: BazzBasic
' Morse: _... ._ __.. __.. _... ._ ... .. _._.
