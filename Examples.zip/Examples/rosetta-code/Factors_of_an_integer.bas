' ============================================
' https://rosettacode.org/wiki/Factors_of_an_integer
' BazzBasic: https://github.com/EkBass/BazzBasic
' ============================================
[inits]
    LET n$ = 0
[main]
    WHILE n$ <= 0
        INPUT "Enter a positive integer: ", n$
        n$ = ABS(INT(n$))
    WEND

    FOR i$ = 1 TO n$ / 2
        IF MOD(n$, i$) = 0 THEN PRINT i$
    NEXT
    PRINT n$
END

' Output:
' Enter a positive integer: 99
' 1
' 3
' 9
' 11
' 33
' 99
