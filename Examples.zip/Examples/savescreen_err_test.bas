' SAVESCREEN error test: only .png allowed, nothing after the error may run
SCREEN 0, 100, 100
SAVESCREEN "nope.jpg"
FILEWRITE "savescreen_err_test.log", "SHOULD NOT RUN"
END
